# Image-to-Minecraft
Takes an image, pixelisiez it, returns the image remade with Minecraft blocks
