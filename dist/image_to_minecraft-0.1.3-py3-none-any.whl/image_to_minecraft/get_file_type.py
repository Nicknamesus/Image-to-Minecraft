import os

def get_filename_type(name):
    t = name[name.rfind("."):]
    return t
